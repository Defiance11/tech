<?php

/**
  * Uninstalling the plugin
  *
  * @package Geeshan
  */